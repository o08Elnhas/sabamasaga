# 🍎 🐧 تعليمات التثبيت على Mac و Linux

## المتطلبات

- **Node.js** (الإصدار 18 أو أحدث)
- **npm** أو **pnpm**

---

## 📥 الخطوة 1: تثبيت Node.js

### على Mac:

#### الطريقة 1: باستخدام Homebrew (الأسهل)
```bash
# تثبيت Homebrew إذا لم يكن مثبتاً
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# تثبيت Node.js
brew install node
```

#### الطريقة 2: التحميل المباشر
1. اذهب إلى [nodejs.org](https://nodejs.org/)
2. حمّل نسخة Mac
3. قم بتشغيل المثبت

### على Linux (Ubuntu/Debian):

```bash
# تحديث قائمة الحزم
sudo apt update

# تثبيت Node.js و npm
sudo apt install nodejs npm
```

### على Linux (Fedora/CentOS):

```bash
sudo dnf install nodejs npm
```

### التحقق من التثبيت:

```bash
node -v
npm -v
```

---

## 📂 الخطوة 2: فك ضغط الملفات

```bash
# انتقل إلى مجلد التحميلات
cd ~/Downloads

# فك ضغط الملف
unzip saba_spa_center.zip

# انتقل إلى مجلد المشروع
cd saba_spa_download
```

---

## 🚀 الخطوة 3: تثبيت المكتبات

```bash
npm install
```

أو باستخدام pnpm (أسرع):
```bash
npm install -g pnpm
pnpm install
```

---

## ▶️ الخطوة 4: تشغيل الموقع

```bash
npm run dev
```

ستظهر رسالة مثل:
```
➜  Local:   http://localhost:5173/
```

---

## 🌐 الخطوة 5: فتح الموقع

افتح متصفحك وانتقل إلى:
```
http://localhost:5173
```

**تم! الموقع يعمل الآن! 🎉**

---

## 🛑 إيقاف الموقع

في الـ Terminal، اضغط:
```
Ctrl + C
```

---

## 🔧 استكشاف الأخطاء الشائعة

### ❌ "command not found: node"
**الحل:**
```bash
# على Mac
brew install node

# على Linux
sudo apt install nodejs npm
```

### ❌ "Port 5173 is already in use"
**الحل:**
```bash
npm run dev -- --port 3000
```

### ❌ "Permission denied"
**الحل:**
```bash
sudo chown -R $(whoami) ~/.npm
npm install
```

### ❌ "Module not found"
**الحل:**
```bash
rm -rf node_modules
npm install
```

---

## 📝 تعديل الموقع

1. افتح مجلد المشروع في محرر نصوص:
```bash
code .  # إذا كان VS Code مثبتاً
```

2. عدّل ملف `client/src/pages/Home.tsx`

3. احفظ الملف

4. الموقع سيحدث تلقائياً في المتصفح

---

## 📦 نشر الموقع

### بناء الموقع:
```bash
npm run build
```

### سيتم إنشاء مجلد `dist/`

انسخ محتويات هذا المجلد إلى خادمك:
```bash
# مثال: نسخ إلى خادم عبر SSH
scp -r dist/* user@yourserver.com:/var/www/html/
```

---

## 🎓 برامج مفيدة

- **VS Code** - محرر نصوص احترافي
```bash
# على Mac
brew install --cask visual-studio-code

# على Linux
sudo apt install code
```

---

## 💡 نصائح مفيدة

### فتح الموقع تلقائياً:
```bash
npm run dev -- --open
```

### استخدام منفذ مخصص:
```bash
npm run dev -- --port 8080
```

### الوصول من أجهزة أخرى في الشبكة:
```bash
# احصل على عنوان IP الخاص بك
ifconfig  # على Mac/Linux

# ثم استخدم
http://YOUR_IP:5173
```

---

## 📞 تحتاج مساعدة؟

1. اقرأ `README_AR.md` للتفاصيل الكاملة
2. اقرأ `QUICK_START.md` للبدء السريع
3. اقرأ `EDITING_GUIDE.md` لتعديل المحتوى

**استمتع بموقعك! 🚀**

