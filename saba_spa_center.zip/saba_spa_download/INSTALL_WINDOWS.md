# 🪟 تعليمات التثبيت على Windows

## المتطلبات

قبل البدء، تأكد من تثبيت:
1. **Node.js** (الإصدار 18 أو أحدث)
2. **Git** (اختياري لكن مفيد)

---

## 📥 الخطوة 1: تثبيت Node.js

### على Windows:

1. اذهب إلى [nodejs.org](https://nodejs.org/)
2. انقر على زر التحميل الأخضر (LTS)
3. قم بتشغيل ملف التثبيت `.msi`
4. اتبع خطوات التثبيت (انقر Next في كل خطوة)
5. تأكد من تحديد ✓ "Add to PATH"
6. انقر Finish

### التحقق من التثبيت:

1. افتح **Command Prompt** (اضغط Windows + R، اكتب `cmd`)
2. اكتب:
```cmd
node -v
npm -v
```
3. يجب أن ترى أرقام الإصدارات

---

## 📂 الخطوة 2: فك ضغط الملفات

1. انقر بزر الماوس الأيمن على ملف `saba_spa_center.zip`
2. اختر "Extract All"
3. اختر مكان الاستخراج (مثل Desktop أو Documents)
4. انقر Extract

---

## 🚀 الخطوة 3: تثبيت المكتبات

1. افتح **Command Prompt** أو **PowerShell**
2. انتقل إلى مجلد المشروع:
```cmd
cd C:\Users\YourUsername\Desktop\saba_spa_download
```
(غيّر `YourUsername` باسم مستخدمك الفعلي)

3. اكتب:
```cmd
npm install
```

4. انتظر حتى ينتهي التثبيت (قد يستغرق دقائق)

---

## ▶️ الخطوة 4: تشغيل الموقع

في نفس Command Prompt، اكتب:
```cmd
npm run dev
```

ستظهر رسالة مثل:
```
➜  Local:   http://localhost:5173/
```

---

## 🌐 الخطوة 5: فتح الموقع

1. افتح متصفحك (Chrome, Firefox, Edge)
2. اكتب في شريط العنوان:
```
http://localhost:5173
```

3. اضغط Enter

**تم! الموقع يعمل الآن! 🎉**

---

## 🛑 إيقاف الموقع

في Command Prompt، اضغط:
```
Ctrl + C
```

---

## 🔧 استكشاف الأخطاء الشائعة

### ❌ "npm is not recognized"
**الحل:**
- أعد تثبيت Node.js
- اختر "Add to PATH" أثناء التثبيت
- أعد تشغيل Command Prompt

### ❌ "Port 5173 is already in use"
**الحل:**
```cmd
npm run dev -- --port 3000
```

### ❌ "Permission denied"
**الحل:**
- افتح Command Prompt كمسؤول (Admin)
- جرب الأمر مرة أخرى

### ❌ "Module not found"
**الحل:**
```cmd
del node_modules
npm install
```

---

## 📝 تعديل الموقع

1. افتح مجلد المشروع
2. افتح ملف `client/src/pages/Home.tsx` بمحرر نصوص (VS Code مثلاً)
3. عدّل المحتوى
4. احفظ الملف
5. الموقع سيحدث تلقائياً في المتصفح

---

## 📦 نشر الموقع

### بناء الموقع:
```cmd
npm run build
```

### سيتم إنشاء مجلد `dist/`

انسخ محتويات هذا المجلد إلى خادمك.

---

## 🎓 برامج مفيدة

- **VS Code** - محرر نصوص احترافي: [code.visualstudio.com](https://code.visualstudio.com/)
- **Git** - للتحكم بالإصدارات: [git-scm.com](https://git-scm.com/)

---

## 📞 تحتاج مساعدة؟

1. اقرأ `README_AR.md` للتفاصيل الكاملة
2. اقرأ `QUICK_START.md` للبدء السريع
3. اقرأ `EDITING_GUIDE.md` لتعديل المحتوى

**استمتع بموقعك! 🚀**

